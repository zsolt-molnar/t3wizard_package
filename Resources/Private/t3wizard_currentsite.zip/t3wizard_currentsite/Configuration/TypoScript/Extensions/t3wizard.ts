page.10 >
page {
    10 = FLUIDTEMPLATE
    10 {
        file.stdWrap.cObject = CASE
        file.stdWrap.cObject {

            key.data = levelfield:-1, backend_layout_next_level, slide
            key.override.field = backend_layout

            1 = TEXT
            1.value = {$page.fluidtemplate.templateRootPath}Home.html
            1.insertData = 1	

            2 = TEXT
            2.value = {$page.fluidtemplate.templateRootPath}TwoCol.html
            2.insertData = 1

            3 = TEXT
            3.value = {$page.fluidtemplate.templateRootPath}NotFound.html
            3.insertData = 1				

            default = TEXT
            default.value = {$page.fluidtemplate.templateRootPath}Default.html
            default.insertData = 1

        }
        partialRootPath     = {$page.fluidtemplate.partialRootPath}
        layoutRootPath      = {$page.fluidtemplate.layoutRootPath}
        variables {

            pageTitle = TEXT
            pageTitle.data = page:title

            siteTitle = TEXT
            siteTitle.data = TSFE:tmpl|setup|sitetitle

            rootPage = TEXT
            rootPage.data = leveluid:0

            logoFile = TEXT
            logoFile.value = {$page.logo.file}
            logoHeight = TEXT
            logoHeight.value = {$page.logo.height}
            logoWidth = TEXT
            logoWidth.value = {$page.logo.width}
            copyrightText = TEXT
            copyrightText.value = {$page.copyright}			
        }
    }
}