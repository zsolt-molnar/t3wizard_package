<?php
// Name of the base-site. This title shows up in the root of the tree structure if you're an 'admin' backend user.
$GLOBALS['TYPO3_CONF_VARS']['SYS']['sitename'] = 'Simona Florea';

// String: This default email address is used when no other "from" address is set for a TYPO3-generated email. You can specify an email address only (ex. info@example.org).
$GLOBALS['TYPO3_CONF_VARS']['MAIL']['defaultMailFromAddress'] = 'noreply@simonaflorea.com';

// String: This default name is used when no other "from" name is set for a TYPO3-generated email.
$GLOBALS['TYPO3_CONF_VARS']['MAIL']['defaultMailFromName'] = 'Simona Florea';