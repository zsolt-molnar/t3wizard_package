<?php
// Name of the base-site. This title shows up in the root of the tree structure if you're an 'admin' backend user.
$GLOBALS['TYPO3_CONF_VARS']['SYS']['sitename'] = 'Simona Florea';

// String: This default email address is used when no other "from" address is set for a TYPO3-generated email. You can specify an email address only (ex. info@example.org).
$GLOBALS['TYPO3_CONF_VARS']['MAIL']['defaultMailFromAddress'] = 'noreply@simonaflorea.com';

// String: This default name is used when no other "from" name is set for a TYPO3-generated email.
$GLOBALS['TYPO3_CONF_VARS']['MAIL']['defaultMailFromName'] = 'Simona Florea';

//preconfigure Mask
$GLOBALS['TYPO3_CONF_VARS']['EXT']['extConf']['mask'] = 'a:4:{s:4:"json";s:88:"typo3conf/ext/t3wizard_currentsite/Resources/Private/Templates/Extensions/Mask/mask.json";s:7:"content";s:87:"typo3conf/ext/t3wizard_currentsite/Resources/Private/Templates/Extensions/Mask/Content/";s:7:"preview";s:76:"typo3conf/ext/t3wizard_currentsite/Resources/Public/Extensions/Mask/Preview/";s:7:"backend";s:87:"typo3conf/ext/t3wizard_currentsite/Resources/Private/Templates/Extensions/Mask/Backend/";}';