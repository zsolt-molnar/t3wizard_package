page {
    fluidtemplate {
        # cat=t3wizard: advanced/100/100; type=string; label=Layout Root Path: Path to layouts
        layoutRootPath                  = EXT:t3wizard_currentsite/Resources/Private/Layouts/Extensions/T3Wizard/
        # cat=t3wizard: advanced/100/110; type=string; label=Partial Root Path: Path to partials
        partialRootPath                 = EXT:t3wizard_currentsite/Resources/Private/Partials/Extensions/T3Wizard/
        # cat=t3wizard: advanced/100/120; type=string; label=Template Root Path: Path to templates
        templateRootPath                = EXT:t3wizard_currentsite/Resources/Private/Templates/Extensions/T3Wizard/
    }
    includePath {
        # cat=t3wizard: advanced/130/100; type=string; label=Css Include Path: Path to css files
        css                             = EXT:t3wizard_currentsite/Resources/Public/Css/
        # cat=t3wizard: advanced/130/110; type=string; label=Icon Include Path: Path to css files
        icons                           = EXT:t3wizard_currentsite/Resources/Public/Icons/
        # cat=t3wizard: advanced/130/120; type=string; label=JavaScript Include Path: Path to css files
        javascript                      = EXT:t3wizard_currentsite/Resources/Public/Javascript/
		images                      	= EXT:t3wizard_currentsite/Resources/Public/Images/
		imagesRel                      	= /typo3conf/ext/t3wizard_currentsite/Resources/Public/Images/
		publicResources                 = EXT:t3wizard_currentsite/Resources/Public/
		privateResources                = EXT:t3wizard_currentsite/Resources/Private/
		lang                			= LLL:EXT:t3wizard_currentsite/Resources/Private/Language/
    }	
	specialPages {
		homepage = 1
		gallery = 27
	}
    meta {
        google                          		= notranslate
		mobile-web-app-capable 					= yes
		apple-mobile-web-app-status-bar-style 	= black
		apple-mobile-web-app-title 				= Simona_Florea			
    }	
	content {
		footerText = 12
		subscribe = 13
	}
	languages = 0,1
}