$(function() {
	$('body').removeClass('no-js');
	if ($('.tx-gallery .backlink').length) {
		$('.section1').remove();
	}
	fitToView();
	headerFilled();
	
	$('#view-list a').click(function() {
		var href = this.href.split('#')[1], top = $('#'+href).offset().top;
		$('html,body').animate({scrollTop:top},500);
		return false;
	});
	
	function getGridSize() {
		return (window.innerWidth < 481) ? 1 :
			   (window.innerWidth < 600) ? 2 : 3;
	}
	
	if($.fn.flexslider) {
		$('#carousel').flexslider({
			animation: 'slide',
			itemWidth: 305,
			move:getGridSize(), 
			controlNav:false,
			minItems: getGridSize(), 
			maxItems: getGridSize()
		});
	}
	
	var flexslider=$('#carousel').data('flexslider');
	
	$(window).resize(function() {
		fitToView();
		
		if($(window).width() > 480) {
			$('ul.navList').show();
		}
		
		if($.fn.flexslider) {
		
			var gridSize = getGridSize();
		
			flexslider.vars.minItems = gridSize;
			flexslider.vars.maxItems = gridSize;
		
		}

	
	});
	
	$(window).scroll(function() {
		headerFilled();
	});
	
	
	
	if($('#homePage').length) {
		scrolled();
	}
	
	$('#scrollDown').click(function() {
		var section2Top = $('#section2').offset().top;
		$('html,body').animate({'scrollTop':section2Top},700);
	});
	
	$('#navTrigger').click(function() {
		
		$(this).toggleClass('active');
		
		$('ul.navList').fadeToggle('normal');
		
		$('#search-input').animate({
					opacity:0,
					width: 0,
					padding:0
		},500, function() { $('form.search-form').removeClass('open') });
	});
	
	
	$('#search-submit').click(function() {
		if($(this).parents('form').hasClass('open')) {
			
			if($('#search-input').val().length < 1) {
				$('#search-input').animate({
					opacity:0,
					width: 0,
					padding:0
				},500, function() { $('form.search-form').removeClass('open') });
				
				return false
			}
			
			
			
		}
		else {
			$('#search-input').animate({
				opacity:1,
				width: 100,
				padding:'0 5px'
			},500);
			
			$('form.search-form').addClass('open');
			
			if($(window).width() < 481) {
				$('#navTrigger').removeClass('active');
				$('ul.navList').fadeOut();
			}
			
			
			return false;
		}
	});
	
});

function fitToView() {	
	if($(window).width() > 481) {
		var wH=$(window).height() ;
		$('section.section').css('min-height',wH);
		$('section.section3 .table-box', '#homePage').css('min-height',wH);
		$('section.section1, section.section3', '#homePage').css('height',wH);
	}
	else {
		$('section.section').css('min-height','');
		$('section.section3 .table-box', '#homePage').css({'min-height':''});
		$('section.section1, section.section3', '#homePage').css('height','');
	}
}

function scrolled() {
	var wh=$(window).height()/2;
	if($(window).width() > 480) {
		$('ul.navList','#navigation').singlePageNav({
			currentClass: 'active',
			speed: 750,
			threshold:wh
		});
	}
	else if ($(window).width() < 481)  {
		var headerH=$('#header').outerHeight();
		$('#navList').singlePageNav({
			currentClass: 'active',
			speed: 750,
			threshold:wh,
			offset:headerH-8
		});
	}
}

function headerFilled() {
	if($(window).scrollTop() > 50) {
		$('#header').addClass('bg-graysemitrans');
	}
	else {
		$('#header').removeClass('bg-graysemitrans');
	}
}

