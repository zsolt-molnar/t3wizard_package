page {
    fluidtemplate {
        # cat=t3wizard: advanced/100/100; type=string; label=Layout Root Path: Path to layouts
        layoutRootPath                  = EXT:t3wizard_currentsite/Resources/Private/Layouts/Extensions/T3Wizard/
        # cat=t3wizard: advanced/100/110; type=string; label=Partial Root Path: Path to partials
        partialRootPath                 = EXT:t3wizard_currentsite/Resources/Private/Partials/Extensions/T3Wizard/
        # cat=t3wizard: advanced/100/120; type=string; label=Template Root Path: Path to templates
        templateRootPath                = EXT:t3wizard_currentsite/Resources/Private/Templates/Extensions/T3Wizard/
    }
}