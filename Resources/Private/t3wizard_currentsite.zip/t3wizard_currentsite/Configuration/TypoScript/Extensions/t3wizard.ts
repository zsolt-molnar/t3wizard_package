page {
	headTag =
    headTag (
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<meta http-equiv="x-dns-prefetch-control" content="off">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	)
}
page.10 >
page {
    10 = FLUIDTEMPLATE
    10 {
        file.stdWrap.cObject = CASE
        file.stdWrap.cObject {

            key.data = levelfield:-1, backend_layout_next_level, slide
            key.override.field = backend_layout

            1 = TEXT
            1.value = {$page.fluidtemplate.templateRootPath}Home.html
            1.insertData = 1	

            2 = TEXT
            2.value = {$page.fluidtemplate.templateRootPath}TwoCol.html
            2.insertData = 1

            3 = TEXT
            3.value = {$page.fluidtemplate.templateRootPath}NotFound.html
            3.insertData = 1				

            default = TEXT
            default.value = {$page.fluidtemplate.templateRootPath}Default.html
            default.insertData = 1

        }
        partialRootPath     = {$page.fluidtemplate.partialRootPath}
        layoutRootPath      = {$page.fluidtemplate.layoutRootPath}
        variables {

            pageTitle = TEXT
            pageTitle.data = page:title

            siteTitle = TEXT
            siteTitle.data = TSFE:tmpl|setup|sitetitle

            rootPage = TEXT
            rootPage.data = leveluid:0

            logoFile = TEXT
            logoFile.value = {$page.logo.file}
            logoHeight = TEXT
            logoHeight.value = {$page.logo.height}
            logoWidth = TEXT
            logoWidth.value = {$page.logo.width}
            copyrightText = TEXT
            copyrightText.value = {$page.copyright}			
        }
    }
}

page {
	10 {
		variables {
            imagePath = TEXT
            imagePath.value = {$page.includePath.imagesRel}		
			galleryPage = TEXT
			galleryPage.value = {$page.specialPages.gallery}		
		}
	}
	includeCSS >
    includeCSS {
		font-awesome	= https://fonts.googleapis.com/css?family=Raleway:400,300
		bootstrap		= {$page.includePath.css}bootstrap.min.css
        flexslider 		= {$page.includePath.css}flexslider.css
		main 			= {$page.includePath.css}main.css
		responsive 		= {$page.includePath.css}responsive.css

    }
	includeJSFooterlibs >
    includeJSFooterlibs  {
		jQuery 				= https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js
		jQuery.forceOnTop 	= 1
		flex 				= {$page.includePath.javascript}jquery.flexslider-min.js
		scroll 				= {$page.includePath.javascript}onepagenav/jquery.scrollTo.js
		nav 				= {$page.includePath.javascript}onepagenav/onepagenav.js
		main 				= {$page.includePath.javascript}main.js
    }
}

[globalVar = TSFE:page|uid = {$page.specialPages.homepage}]
	page.bodyTag >

	page.bodyTagCObject = TEXT
	page.bodyTagCObject.field = uid
	page.bodyTagCObject.wrap = <body id="homePage" class="page-|"> 
[GLOBAL]

###########################
#### AJAX PAGES 	   ####
###########################

ajax = PAGE
ajax{
  config {
    disableAllHeaderCode = 1
    additionalHeaders = Content-type:text/html
    xhtml_cleaning = 0
    admPanel = 0
    debug = 0
	linkVars = L
  }
}

newsletter < ajax
newsletter.typeNum = 6666
newsletter.5 = TEXT
newsletter.5.wrap = <title>|</title>
newsletter.5.field = title
newsletter.10 < styles.content.get
newsletter.10.select.where = colPos = 0