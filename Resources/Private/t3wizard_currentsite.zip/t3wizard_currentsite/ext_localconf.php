<?php
if (!defined('TYPO3_MODE')) {
    die('Access denied.');
}

if (\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::isLoaded('realurl')) {
	$settings = $GLOBALS['TYPO3_CONF_VARS']['EXT']['extConf']['t3wizard'];
	if($settings['UseRealUrlConfig'] == 1){
		@include_once(\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extPath($_EXTKEY,'Configuration/RealURL/Default.php'));
	}
}