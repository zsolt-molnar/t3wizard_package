####################
#### NAVIGATION ####
####################
lib.mainMenu = COA
lib.mainMenu {
    10 = HMENU
    10 {
		entryLevel = 0
        1 = TMENU
        1 {
            wrap = 	<ul class="navList">|</ul>
            expAll = 1
            noBlur = 1
            NO = 1
            NO {
				wrapItemAndSub = <li>|</li>		
				doNotLinkIt = 1 
				stdWrap.wrap = <a href="#{field:tx_realurl_pathsegment}" title="{field:title}">|</a>
				stdWrap.insertData = 1			
            }
			
            ACT < .NO
            ACT {
				wrapItemAndSub = <li>|</li>	
				stdWrap.wrap = <a class="active" href="#{field:tx_realurl_pathsegment}" title="{field:title}">|</a>
            }
            CUR < .ACT		
        }		
    }
}

lib.langMenu = HMENU
lib.langMenu {
	special = language
	special.value = {$page.languages}
	special.normalWhenNoLanguage = 0
	addQueryString = 1
	addQueryString {
		method = GET,POST
		exclude = L,cHash
	}
	wrap =  <ul class="langBar">|</ul>
	1 = TMENU
	1 {
		noBlur = 1
		NO = 1
		NO {
			linkWrap = <li>|</li>
			stdWrap.override = SV || EN
			ATagParams = lang="sv" title="SV" |*| lang="en" title="EN"
			doNotLinkIt = 1
			stdWrap {
				typolink {
					parameter.data = page:uid
					additionalParams = &L=0 || &L=1
					addQueryString = 1
					addQueryString.exclude = L,id,cHash,no_cache
					addQueryString.method = GET
					useCacheHash = 1
					no_cache = 0
				}
			}
		}
		ACT < .NO
		ACT {
			stdWrap {
				typolink {
					ATagParams = class="active"
				}
			}
		}
		CUR < .ACT			
	}
}