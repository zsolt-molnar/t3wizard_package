lib.footerText = RECORDS
lib.footerText {
	source = {$page.content.footerText}
	tables = tt_content
	dontCheckPid = 1
}

lib.subscribe = RECORDS
lib.subscribe {
	source = {$page.content.subscribe}
	tables = tt_content
	dontCheckPid = 1
}